@extends('dashboard.layout.main')
@section('container1')

    <body>
        <div class=" ">
            <div class=" text-center" id="map"></div>
            <center>
                <div class="col p-5 mb-4 bg-light rounded-3">
                    <h2 class=" blod">Deskripsi</h2>
                    <div class=" pt-2 col-10 " id="text"></div>
                </div>
            </center>
        </div>
    </body>

    </html>
@endsection
