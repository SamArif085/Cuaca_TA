
<?php $__env->startSection('konten'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <main class="form-signin">
                <div class="text-center">
                    <img src="img/logo.png" class="rounded" alt="..." width="300" height="auto">
                </div>
                <h1 class="h3 mb-3 fw-normal text-center">Login</h1>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <form action="/login" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating">
                        <input type="text" name="username" required
                            class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="Username"
                            autofocus required value="<?php echo e(old('username')); ?>">
                        <label for="username">Username</label>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating">
                        <input type="password" name="password" required class="form-control" id="password"
                            placeholder="Password">
                        <label for="password">Password</label>
                    </div>
                    <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
                </form>
                <small class="d-block text-center mt-2">Belum punya akun ? <a href="/register">Buat Akun</a></small>
                <small class="d-block text-center mt-2"> <a href="/">Kembali<span
                            data-feather="corner-down-left"></span></a></small>
            </main>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Project\Cuaca_TA\resources\views/login/index.blade.php ENDPATH**/ ?>