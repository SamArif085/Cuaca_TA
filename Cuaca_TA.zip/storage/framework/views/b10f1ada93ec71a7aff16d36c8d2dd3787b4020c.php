
<?php $__env->startSection('container1'); ?>
    <div class=" container mr-3 ">
        <div class="row p-md-5 p-sm-5 ">
            <div class="col-3 bg-primary text-white p-2">
                <h5 id="">Halo <?php echo e(auth()->user()->name); ?></h5>
            </div>
            <div class="col bg-dark text-white p-2 result2">
            </div>
            <div class="col-3 bg-primary text-white p-2 result5">
                <h5> Potensi Badai: </h5>
            </div>
        </div>
    </div>
    <div class=" container-fluid">
        <div class=" row p-md-5 p-sm-5 ">
            <div class="col-2">
                <select class="form-select form-select-sm input-keyword" id="Provinsi">
                    <option value="0" selected>Pilih Provinsi</option>
                    <?php $__currentLoopData = $Provinsi['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->nama_provinsi); ?>">
                            <h4><?php echo e($p->nama_provinsi); ?></h4>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-2">
                <select class="form-select form-select-sm input-keyword2 src" name="nama_provinsi" id="kota">
                    <option value='0' selected>Pilih</option>
                </select>
            </div>
            
        </div>
    </div>
    <div class="col p-5 mb-4 bg-light rounded-3">
        <div class="container-fluid py-5">
            <div class="d-flex justify-between">
                <div class="col-5 p-md-5 p-sm-5">
                    <h1 class="display-5 fw-bold">Cuaca Hari Ini</h1>
                    <h2 class="result6"></h2>
                    <div class="result fs-4"></div>
                </div>
                <div class="col-md-8 fs-4 result8"></div>
            </div>
            
        </div>
    </div>
    <div class="col p-5 mb-4 bg-light rounded-3">
        <div class="container-fluid py-5">
            <div class="">
                <div class="col-8 p-md-5 ">
                    <h1 class="display-5 fw-bold">Prediksi Cuaca Kedepan</h1>
                    <h2 class="result7"></h2>
                </div>
                <div class="container  p-md-5 p-sm-5 d-flex">
                    <div class="col-md-8 fs-4 col-sm-8  result3"></div>
                    <div class="col-md-8 fs-4 col-sm-8  result4"></div>
                </div>
                
            </div>
        </div>
        
    </div>
    <div class="container d-flex justify-content-center">
        <div class="col-8 p-5 mb-4 bg-light rounded-3" id="ul">
            <div class="d-flex flex-row justify-content-between p-3 adiv text-white">
                <i class="fas fa-chevron-left"></i>
                <span class="pb-3">feedback</span>
                <i class="fas fa-times"></i>
            </div>
            <div class="mt-2 p-4 text-center">
                <h4 class="mb-3">Apakah Ramalah Hari Ini Sudah Akurat?</h4>
                <h5 class="px-3">Berikan Ulasan</h5>
                <div class="d-flex flex-row justify-content-center mt-5 g-2">
                    <form id="ulasan" class="">
                        
                        <div class="col pb-5 p-5">
                            <button type="submit" class="btn btn-success save-data" value="Akurat" name="isi_ulasan"
                                id="tbl1" autocomplete="off">Akurat</button>
                            
                            
                            <span class="text-danger" id="akuratError"></span>
                        </div>
                        
                        <input hidden type="text" id="id" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                        
                        
                    </form>
                    <form id="ulasan1" class=" ml-5">
                        
                        <div class="col pb-5 p-5">
                            <button type="submit" class="btn btn-danger save-data" value="Tidak Akurat" name="isi_ulasan"
                                id="tbl2" autocomplete="off">Tidak Akurat</button>
                            
                            
                            <span class="text-danger" id="tidakError"></span>
                        </div>
                        
                        <input hidden type="text" id="id" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                        
                        
                    </form>
                </div>
                <div class=" pb-5">
                    <div class="th" id="th"></div>
                </div>

                <div class=" pt-5 position-relative">
                    <h6 class=" ">Developer Tim</h6>
                    <h6 class=""> @2022</h6>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Project\Cuaca_TA\resources\views/dashboard/index.blade.php ENDPATH**/ ?>