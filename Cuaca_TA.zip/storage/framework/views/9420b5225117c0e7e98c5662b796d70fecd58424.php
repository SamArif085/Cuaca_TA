<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <div class=" container-fluid position-relative ">
        <img src="<?php echo e(asset('img/logo2.png')); ?>" class="rounded " alt="..." width="150" height="auto">
    </div>

    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
        data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="navbar-nav">
        <div class="nav-item text-nowrap position-relative">
            <a class=" btn btn-success px-3 mx-5 mx-md-3 mx-sm-3" href="/login">Login <span data-feather="log-in"></a>
        </div>
    </div>
</header>
<?php /**PATH D:\Aplikasi\Project\Cuaca_TA\resources\views/partials/navbar.blade.php ENDPATH**/ ?>