
<?php $__env->startSection('container2'); ?>
    <div class="col p-5 mb-4 bg-light rounded-3">
        <div class="container-fluid py-5">
            <table id="example" class="table table-striped" style="width:100%">
                <thead>

                    <tr>
                        <th>No</th>
                        <th>Isi Ulasan</th>
                        <th>Nama Kota</th>
                        <th>Tanggal dan Waktu</th>
                    </tr>
                </thead>

                <?php
                    $no = 1;
                ?>
                <tbody>
                    <?php $__currentLoopData = $Historis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($h->isi_ulasan); ?></td>
                            <td><?php echo e($h->nama_kota); ?></td>
                            <td><?php echo e($h->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

             
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Project\Cuaca_TA\resources\views/dashboard/historis/index.blade.php ENDPATH**/ ?>