
<?php $__env->startSection('container1'); ?>

    <body>
        <div class=" ">
            <div class=" text-center" id="map"></div>
            <center>
                <div class="col p-5 mb-4 bg-light rounded-3">
                    <h2 class=" blod">Deskripsi</h2>
                    <div class=" pt-2 col-10 " id="text"></div>
                </div>
            </center>
        </div>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplikasi\Project\Cuaca_TA\resources\views/dashboard/gempa/index.blade.php ENDPATH**/ ?>